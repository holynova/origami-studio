// Path-hosted static assets. Paper in Motion, 2026-10-23. GPL-3.0.
const BASE = '/origami-studio';
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === BASE) {
      url.pathname = `${BASE}/`;
      return Response.redirect(url.toString(), 308);
    }
    if (!url.pathname.startsWith(`${BASE}/`)) return new Response('Not found', {status: 404});
    url.pathname = url.pathname.slice(BASE.length);
    const response = await env.ASSETS.fetch(new Request(url, request));
    const location = response.headers.get('location');
    if (!location) return response;
    const target = new URL(location, url);
    if (target.origin !== url.origin || target.pathname.startsWith(`${BASE}/`)) return response;
    target.pathname = BASE + target.pathname;
    const headers = new Headers(response.headers);
    headers.set('location', target.toString());
    return new Response(response.body, {status: response.status, headers});
  }
};
